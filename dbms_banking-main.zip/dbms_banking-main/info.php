<?php

$acc = '';
echo $acc;
?>