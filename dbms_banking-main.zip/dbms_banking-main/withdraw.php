
<?php
include 'dbconnect.php';


    @$withdraw = $_POST["inputWithdraw"];
    @$acc1  = $_POST["inputacc"];
    
    $sql1 = "UPDATE balance SET withdraw = $withdraw,t_savings = t_savings-$withdraw where accountno = $acc1";

 
?>
     


